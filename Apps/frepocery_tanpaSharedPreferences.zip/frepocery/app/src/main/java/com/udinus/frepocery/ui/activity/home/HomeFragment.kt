package com.udinus.frepocery.ui.activity.home

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import com.udinus.frepocery.R
import com.udinus.frepocery.databinding.ActivityAddressBinding
import com.udinus.frepocery.model.dummy.HomeModel
import com.udinus.frepocery.model.dummy.HomeVerticalModel
import com.udinus.frepocery.ui.activity.detail.DetailActivity
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.fragment_home.*


class HomeFragment : Fragment(), HomeAdapter.ItemAdapterCallback {
    private var productList : ArrayList<HomeModel> = ArrayList()


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_home, container, false)
        return root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        initDataDummy()
        var adapter = HomeAdapter(productList, this)
        var layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        rcList.layoutManager = layoutManager
        rcList.adapter = adapter

        val sectionPagerAdapter = SectionPagerAdapter(
            childFragmentManager
        )

        viewPager.adapter = sectionPagerAdapter
        tabLayout.setupWithViewPager(viewPager)

        fab.setOnClickListener { view ->
            Snackbar.make(view, "Here's a Snackbar", Snackbar.LENGTH_LONG)
                .setAction("Action", null)
                .show()
        }
    }

    fun initDataDummy(){
        productList = ArrayList()
        productList.add(HomeModel("Jagung", "3250", R.drawable.jagung, 5f,"Jagung rebus mengandung vitamin C, karotenoid, dan bioflavonoid. Kandungan ini sangat baik mengontrol jumlah kolesterol di dalam darah"))
        productList.add(HomeModel("Tomat", "5000", R.drawable.tomat, 5f,"Tomat merupakan buah yang kaya akan air dengan sejumlah nutrisi penting bagi tubuh"))
        productList.add(HomeModel("Bayam", "3200", R.drawable.bayam, 4f,"Bayam mengandung vitamin C yang penting untuk tubuh manusia. vitamin C antara lain dapat membantu mengobati kanker, diabetes, infeksi virus dan bakteri, "))
        productList.add(HomeModel("Cabai", "13250", R.drawable.cabai, 4f,"Cabai juga digunakan sebagai obat alami untuk masalah pencernaan pencernaan dan meningkatkan metabolisme"))
    }

    override fun onClick(v: View, data: HomeModel) {
        val detail = Intent(activity, DetailActivity::class.java)
        detail.putExtra("data",data)
        startActivity(detail)
    }


}