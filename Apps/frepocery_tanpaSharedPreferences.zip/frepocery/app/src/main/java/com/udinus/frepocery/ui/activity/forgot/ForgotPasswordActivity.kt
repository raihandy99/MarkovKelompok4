package com.udinus.frepocery.ui.activity.forgot

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.core.graphics.drawable.toDrawable
import com.google.firebase.auth.FirebaseAuth
import com.udinus.frepocery.R
import com.udinus.frepocery.databinding.ActivityForgotPasswordBinding
import com.udinus.frepocery.ui.activity.MainActivity
import com.udinus.frepocery.ui.activity.signin.SignInActivity
import com.udinus.frepocery.ui.activity.success.SuccessChangePassword
import kotlinx.android.synthetic.main.activity_forgot_password.*
import kotlinx.android.synthetic.main.activity_sign_in.*


class ForgotPasswordActivity : AppCompatActivity() {

    lateinit var auth: FirebaseAuth
    private  lateinit var binding: ActivityForgotPasswordBinding
    private var progressDialog : Dialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityForgotPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // initialising Firebase auth object
        auth = FirebaseAuth.getInstance()

        binding.btnSend.setOnClickListener {
            val email = binding.edtTxtEmail.text.toString()

            var status = true

            binding.apply {
                if (email.isBlank()) {
                    status = false
                    Toast.makeText(this@ForgotPasswordActivity, "email kosong", Toast.LENGTH_SHORT).show()
                } else if (!email.isEmailValid()) {
                    status = false
                    Toast.makeText(this@ForgotPasswordActivity, "email tidak valid", Toast.LENGTH_SHORT)
                        .show()
                }
            }
                auth!!.sendPasswordResetEmail(email) .addOnCompleteListener(this) {
                    if (it.isSuccessful) {
                        val i = Intent(this@ForgotPasswordActivity, SignInActivity::class.java)
                        Toast.makeText(this@ForgotPasswordActivity, "Kami telah mengirimkan instruksi untuk mengatur ulang kata sandi Anda!", Toast.LENGTH_SHORT).show()
                        startActivity(i)
                        finish()
                    } else
                        Toast.makeText(this@ForgotPasswordActivity, "Gagal mengirim email setel ulang!", Toast.LENGTH_SHORT).show()

            }
            btn_send.visibility = View.GONE
                    showProgress()
            Handler().postDelayed({
                hideProgress()
                btn_send.visibility = View.VISIBLE
            }, 3000)
        }
    }

    fun showLoadingDialog(context: Context): Dialog {
        val progressDialog = Dialog(context)

        progressDialog.let {
            it.show()
            it.window?.setBackgroundDrawable(Color.TRANSPARENT.toDrawable())
            it.setContentView(R.layout.dialog_loader)
            it.setCancelable(false)
            it.setCanceledOnTouchOutside(false)
            return it
        }
    }

    private fun showProgress(){
        hideProgress()
        progressDialog = showLoadingDialog(this);
    }
    private fun hideProgress(){
        progressDialog?.let { if(it.isShowing)it.cancel() }
    }

    fun back(view: View?) {
        val i = Intent(this@ForgotPasswordActivity, SignInActivity::class.java)
        startActivity(i)
    }

    fun postSendRequest(view: View?) {
        val i = Intent(this@ForgotPasswordActivity, SuccessChangePassword::class.java)
        startActivity(i)
    }

    fun String.isEmailValid() = Patterns.EMAIL_ADDRESS.matcher(this).matches()
}