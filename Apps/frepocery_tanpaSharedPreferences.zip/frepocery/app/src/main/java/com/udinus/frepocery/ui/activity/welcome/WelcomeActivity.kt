package com.udinus.frepocery.ui.activity.welcome

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.udinus.frepocery.R
import com.udinus.frepocery.ui.activity.signin.SignInActivity


class WelcomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)
    }

    fun GetStart(view: View?) {
        val i = Intent(this@WelcomeActivity, SignInActivity::class.java)
        startActivity(i)
    }

}