package com.udinus.frepocery.ui.activity.signin

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.util.Patterns
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.graphics.drawable.toDrawable
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.udinus.frepocery.R
import com.udinus.frepocery.databinding.ActivitySignInBinding
import com.udinus.frepocery.ui.activity.MainActivity
import com.udinus.frepocery.ui.activity.forgot.ForgotPasswordActivity
import com.udinus.frepocery.ui.activity.signup.SignUpActivity
import kotlinx.android.synthetic.main.activity_sign_in.*

class SignInActivity : AppCompatActivity() {

    private  lateinit var binding: ActivitySignInBinding
    lateinit var auth: FirebaseAuth
    private var progressDialog : Dialog? = null
    private lateinit var googleSignInClient: GoogleSignInClient

    private fun updateUI(currentUser: FirebaseUser?) {
        if (currentUser != null){
            startActivity(Intent(this@SignInActivity, MainActivity::class.java))
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignInBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // initialising Firebase auth object
        auth = FirebaseAuth.getInstance()

        val gso = GoogleSignInOptions
            .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(applicationContext, gso)

        binding.iconClickGoole.setOnClickListener{
            googleSignIn()
        }

        binding.btnSignin.setOnClickListener {
            val email = binding.edtTxtEmail.text.toString()
            val pass = binding.edtTxtPass.text.toString()
            var status = true

            binding.apply{
                if (email.isBlank()){
                    status = false
                    Toast.makeText(this@SignInActivity,"email kosong", Toast.LENGTH_SHORT).show()
                } else if(!email.isEmailValid()){
                    status = false
                    Toast.makeText(this@SignInActivity,"email tidak valid", Toast.LENGTH_SHORT).show()
                }

                if (pass.isBlank()){
                    status = false
                    Toast.makeText(this@SignInActivity,"password kosong", Toast.LENGTH_SHORT).show()
                } else if (pass.length < 8){
                    status = false
                    Toast.makeText(this@SignInActivity,"password kurang dari 8", Toast.LENGTH_SHORT).show()
                }
            }
            if (status){
                auth.signInWithEmailAndPassword(email, pass).addOnCompleteListener(this) {
                    if (it.isSuccessful) {
                        val i = Intent(this@SignInActivity, MainActivity::class.java)
                        startActivity(i)
                        finish()
                    } else
                        Toast.makeText(this@SignInActivity, "gagal", Toast.LENGTH_SHORT).show()
                }
            }
            btn_signin.visibility = View.GONE
            showProgress()
            Handler().postDelayed({
                hideProgress()
                btn_signin.visibility = View.VISIBLE
            }, 3000)


        }
    }
    private fun googleSignIn() {
        val signInIntent = googleSignInClient.signInIntent
        resultLauncher.launch(signInIntent)
    }

    private fun loginWithGoogle(idToken: String) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    val user = auth.currentUser
                    updateUI(user)
                } else {
                    // If sign in fails, display a message to the user.
                    updateUI(null)
                }
            }
    }

    private var resultLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)

            try {
                val account = task.getResult(ApiException::class.java)!!
                loginWithGoogle(account.idToken!!)

            } catch (e: ApiException) {
            }
        }
    }

    fun signUp(view: View?) {
        val i = Intent(this@SignInActivity, SignUpActivity::class.java)
        startActivity(i)
    }

    fun forgotPass(view: View?) {
        val i = Intent(this@SignInActivity, ForgotPasswordActivity::class.java)
        startActivity(i)
    }

    fun showLoadingDialog(context: Context): Dialog {
        val progressDialog = Dialog(context)

        progressDialog.let {
            it.show()
            it.window?.setBackgroundDrawable(Color.TRANSPARENT.toDrawable())
            it.setContentView(R.layout.dialog_loader)
            it.setCancelable(false)
            it.setCanceledOnTouchOutside(false)
            return it
        }
    }

    private fun showProgress(){
        hideProgress()
        progressDialog = showLoadingDialog(this);
    }
    private fun hideProgress(){
        progressDialog?.let { if(it.isShowing)it.cancel() }
    }

    override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        val currentUser = auth.currentUser
        updateUI(auth.currentUser)

    }

    fun String.isEmailValid() = Patterns.EMAIL_ADDRESS.matcher(this).matches()
}