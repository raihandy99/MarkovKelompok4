package com.udinus.frepocery.ui.activity.addres

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Toast
import androidx.core.graphics.drawable.toDrawable
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.udinus.frepocery.R
import com.udinus.frepocery.databinding.ActivityAddressBinding
import com.udinus.frepocery.databinding.ActivitySignUpBinding
import com.udinus.frepocery.ui.activity.signin.SignInActivity
import com.udinus.frepocery.ui.activity.signup.SignUpActivity
import com.udinus.frepocery.ui.activity.success.SuccessActivity
import kotlinx.android.synthetic.main.activity_address.*
import kotlinx.android.synthetic.main.activity_forgot_password.*
import kotlinx.android.synthetic.main.activity_sign_in.*

class AddressActivity : AppCompatActivity() {
    private  lateinit var binding: ActivityAddressBinding
    private lateinit var database: FirebaseDatabase
    lateinit var auth: FirebaseAuth
    private var progressDialog : Dialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddressBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // initialising Firebase auth object
        auth = FirebaseAuth.getInstance()
        //realtime
        database = Firebase.database

        btn_singUp.setOnClickListener {
            val phone = binding.edtTxtPhone.text.toString().trim()
            val postalCode = binding.edtTxtCode.text.toString().trim()
            val address = binding.edtTxtAddress.text.toString().trim()
            val city = binding.edtTxtCity.text.toString().trim()

            var status = true

            binding.apply{
                if(phone.isBlank()){
                    status = false
                    Toast.makeText(this@AddressActivity,"telepon kosong", Toast.LENGTH_SHORT).show()
                }else if (phone.length < 12){
                    status = false
                    Toast.makeText(this@AddressActivity,"telepon kurang dari 12", Toast.LENGTH_SHORT).show()
                }
                if (postalCode.isBlank()){
                    status = false
                    Toast.makeText(this@AddressActivity,"kode pos kosong", Toast.LENGTH_SHORT).show()
                }
                if (address.isBlank()){
                    status = false
                    Toast.makeText(this@AddressActivity,"alamat kosong", Toast.LENGTH_SHORT).show()
                }
                if (city.isBlank()){
                    status = false
                    Toast.makeText(this@AddressActivity,"kota kosong", Toast.LENGTH_SHORT).show()
                }
            }
            if(status){
                saveToDatabase(phone, postalCode.toInt(), address, city)
            }

            btn_singUp.visibility = View.GONE
                    showProgress()
            Handler().postDelayed({
                hideProgress()
                btn_singUp.visibility = View.VISIBLE
            }, 3000)
        }
    }

    fun saveToDatabase(phone:String, postalCode:Int, addres:String, city:String) {
        val myRef = database.reference.child("users")
        val user = auth.currentUser

        val data = hashMapOf(
            "phone" to phone,
            "postalCode" to postalCode,
            "homeAddress" to addres,
            "city" to city,
        )

        myRef.child(user?.displayName.toString()).child("address").setValue(data).addOnCompleteListener {
            if(it.isSuccessful){
                Toast.makeText(this@AddressActivity, "Berhasil Tersimpan", Toast.LENGTH_SHORT).show()
                val i = Intent(this@AddressActivity, SuccessActivity::class.java)
                startActivity(i)
                finish()
            }else
                Toast.makeText(this@AddressActivity, "gagal", Toast.LENGTH_SHORT).show()
        }
    }

    fun back(view: View?) {
        val i = Intent(this@AddressActivity, SignUpActivity::class.java)
        startActivity(i)
    }

    fun postSignUp(view: View?) {
        val i = Intent(this@AddressActivity, SignInActivity::class.java)
        startActivity(i)
    }

    fun showLoadingDialog(context: Context): Dialog {
        val progressDialog = Dialog(context)

        progressDialog.let {
            it.show()
            it.window?.setBackgroundDrawable(Color.TRANSPARENT.toDrawable())
            it.setContentView(R.layout.dialog_loader)
            it.setCancelable(false)
            it.setCanceledOnTouchOutside(false)
            return it
        }
    }

    private fun showProgress(){
        hideProgress()
        progressDialog = showLoadingDialog(this);
    }
    private fun hideProgress(){
        progressDialog?.let { if(it.isShowing)it.cancel() }
    }

}