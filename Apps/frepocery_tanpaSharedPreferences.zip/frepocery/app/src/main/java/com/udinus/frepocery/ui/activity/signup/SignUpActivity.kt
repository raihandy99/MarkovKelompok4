package com.udinus.frepocery.ui.activity.signup

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.ktx.userProfileChangeRequest
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.udinus.frepocery.databinding.ActivitySignUpBinding
import com.udinus.frepocery.ui.activity.addres.AddressActivity
import com.udinus.frepocery.ui.activity.signin.SignInActivity
import kotlinx.android.synthetic.main.activity_sign_up.*


class SignUpActivity : AppCompatActivity() {

    private  lateinit var binding: ActivitySignUpBinding
    lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // initialising Firebase auth object
        auth = FirebaseAuth.getInstance()

        //realtime
        database = Firebase.database

        btnContinue.setOnClickListener {
            val name = binding.edtTxtUser.text.toString().trim()
            val email = binding.edtTxtEmail.text.toString().trim()
            val password = binding.edtTxtPass.text.toString().trim()

            var status = true

            binding.apply{
                if(name.isBlank()){
                    status = false
                    Toast.makeText(this@SignUpActivity,"nama kosong", Toast.LENGTH_SHORT).show()
                }
                if (email.isBlank()){
                    status = false
                    Toast.makeText(this@SignUpActivity,"email kosong", Toast.LENGTH_SHORT).show()
                } else if(!email.isEmailValid()){
                    status = false
                    Toast.makeText(this@SignUpActivity,"email tidak valid", Toast.LENGTH_SHORT).show()
                }
                if (password.isBlank()){
                    status = false
                    Toast.makeText(this@SignUpActivity,"password kosong", Toast.LENGTH_SHORT).show()
                } else if (password.length < 8){
                    status = false
                    Toast.makeText(this@SignUpActivity,"password kurang dari 8", Toast.LENGTH_SHORT).show()
                }
            }

            if (status){
                auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this) {
                    if (it.isSuccessful) {
                        val user = auth.currentUser
                        val update = userProfileChangeRequest { displayName = name }

                        user!!.updateProfile(update).addOnCompleteListener {
                            saveToDatabase(auth.currentUser, password)
                        }
                        val i = Intent(this@SignUpActivity, AddressActivity::class.java)
                        startActivity(i)
                        finish()
                    } else
                        Toast.makeText(this@SignUpActivity, "gagal", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }


    fun SignIn(view: View?) {
        val i = Intent(this@SignUpActivity, SignInActivity::class.java)
        startActivity(i)
    }

    fun postLogin(view: View?) {
        val i = Intent(this@SignUpActivity, AddressActivity::class.java)
        startActivity(i)
    }

    fun saveToDatabase(user:FirebaseUser?, password:String) {
        val myRef = database.reference.child("users")

        val data = hashMapOf(
            "username" to user?.displayName.toString(),
            "uid" to user?.uid.toString(),
            "email" to user?.email,
            "password" to password,
        )
        myRef.child(user?.displayName.toString()).setValue(data)
    }

    fun back(view: View?) {
        val i = Intent(this@SignUpActivity, SignInActivity::class.java)
        startActivity(i)
    }

    fun String.isEmailValid() = Patterns.EMAIL_ADDRESS.matcher(this).matches()
}