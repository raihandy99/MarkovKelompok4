package com.udinus.frepocery.ui.activity.splashscreen

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import com.udinus.frepocery.R
import com.udinus.frepocery.ui.activity.welcome.WelcomeActivity

class SplashScreenActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splashscreen)

        Handler().postDelayed({
            val i = Intent(this@SplashScreenActivity, WelcomeActivity::class.java)
            startActivity(i)
            finish()
        }, 3000)
    }
}