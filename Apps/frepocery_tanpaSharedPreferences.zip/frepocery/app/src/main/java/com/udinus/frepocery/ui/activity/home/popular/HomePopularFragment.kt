package com.udinus.frepocery.ui.activity.home.popular

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.udinus.frepocery.R
import com.udinus.frepocery.model.dummy.HomeModel
import com.udinus.frepocery.ui.activity.detail.DetailActivity
import com.udinus.frepocery.ui.activity.home.newproduct.HomeNewProductAdapter
import kotlinx.android.synthetic.main.fragment_home.*


class HomePopularFragment : Fragment(), HomeNewProductAdapter.ItemAdapterCallback {
    private var productList : ArrayList<HomeModel> = ArrayList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home_new_productragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        initDataDummy()
        var adapter = HomeNewProductAdapter(productList, this)
        var layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(activity)
        rcList.layoutManager = layoutManager
        rcList.adapter = adapter
    }

    fun initDataDummy(){
        productList = ArrayList()
        productList.add(HomeModel("Tomat", "5000", R.drawable.tomat, 5f,"Tomat merupakan buah yang kaya akan air dengan sejumlah nutrisi penting bagi tubuh"))
        productList.add(HomeModel("Bayam", "3200", R.drawable.bayam, 4f,"Bayam mengandung vitamin C yang penting untuk tubuh manusia. vitamin C antara lain dapat membantu mengobati kanker, diabetes, infeksi virus dan bakteri, "))
        productList.add(HomeModel("Cabai", "13250", R.drawable.cabai, 4f,"Cabai juga digunakan sebagai obat alami untuk masalah pencernaan pencernaan dan meningkatkan metabolisme"))
    }

    override fun onClick(v: View, data: HomeModel) {
        val detail = Intent(activity, DetailActivity::class.java)
        detail.putExtra("data", data)
        startActivity(detail)
    }
}