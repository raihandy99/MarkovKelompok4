package com.udinus.frepocery.ui.activity.home.newproduct

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.udinus.frepocery.R
import com.udinus.frepocery.model.dummy.HomeModel
import com.udinus.frepocery.ui.activity.detail.DetailActivity
import kotlinx.android.synthetic.main.fragment_home.*


class HomeNewProductFragment : Fragment(), HomeNewProductAdapter.ItemAdapterCallback {
    private var productList : ArrayList<HomeModel> = ArrayList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home_new_productragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        initDataDummy()
        var adapter = HomeNewProductAdapter(productList, this)
        var layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(activity)
        rcList.layoutManager = layoutManager
        rcList.adapter = adapter
    }

    fun initDataDummy() {
        productList = ArrayList()
        productList.add(HomeModel("Jagung", "3250", R.drawable.jagung, 5f,"Jagung rebus mengandung vitamin C, karotenoid, dan bioflavonoid. Kandungan ini sangat baik mengontrol jumlah kolesterol di dalam darah"))
        productList.add(HomeModel("Tomat", "5000", R.drawable.tomat, 5f,"Tomat merupakan buah yang kaya akan air dengan sejumlah nutrisi penting bagi tubuh"))
        productList.add(HomeModel("Bayam", "3200", R.drawable.bayam, 4f,"Bayam mengandung vitamin C yang penting untuk tubuh manusia. vitamin C antara lain dapat membantu mengobati kanker, diabetes, infeksi virus dan bakteri, "))
        productList.add(HomeModel("Bawang Merah", "22500", R.drawable.bawang_merah, 5f, "bawang merah juga berkhasiat untuk menjaga kesehatan tulang. Mengonsumsi bawang merah secara rutin dapat membantu meningkatkan kepadatan tulang"))
        productList.add(HomeModel("Bawang Putih", "13250", R.drawable.bawang_putih, 4f,"bawang putih dapat dimanfaatkan sebagai pestisida. Artinya, bawang dapat digunakan sebagai pengusir hama yang secara tidak langsung menggerogoti tanaman"))
        productList.add(HomeModel("Cabai", "13250", R.drawable.cabai, 4f,"Cabai juga digunakan sebagai obat alami untuk masalah pencernaan pencernaan dan meningkatkan metabolisme"))
        productList.add(HomeModel("Kacang Panjang", "9000", R.drawable.kacang_panjang, 3.5f,"kacang panjang ini mampu menjaga imun tubuh agar terhindar dari bakteri penyakit. Menjaga kekebalan tubuh dapat menghindarkan Anda tertular virus dan berbagai penyakit"))
        productList.add(HomeModel("Daun Bawang", "25000", R.drawable.daun_bawang, 4f,"Bawang daun merupakan sayuran rendah kalori namun tinggi serat. Sifat tersebut yang membuat sayuran ini bisa membuat rasa kenyang lebih lama"))
        productList.add(HomeModel("Terong", "7000", R.drawable.terong, 3.5f, "terong dipercaya bisa membantu memelihara kesehatan jantung. Selain itu, sayuran ini juga mengandung flavonoid atau pigmen yang larut dalam air sehingga bisa mengatasi berbagai gangguan pada jantung"))
        productList.add(HomeModel("Wortel", "12000", R.drawable.wortel, 3.5f,"Wortel dengan warna khas oranye merupakan salah satu sayuran yang tinggi akan serat, rendah lemak, dan rendah kalori. Kandungan serat yang tinggi pada wortel dipercaya dapat membantu menurunkan kolestrol"))
    }

    override fun onClick(v: View, data: HomeModel) {
        val detail = Intent(activity, DetailActivity::class.java)
        detail.putExtra("data", data)
        startActivity(detail)
    }
}