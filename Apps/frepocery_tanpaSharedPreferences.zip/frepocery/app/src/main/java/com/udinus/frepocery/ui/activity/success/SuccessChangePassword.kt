package com.udinus.frepocery.ui.activity.success

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.udinus.frepocery.R
import com.udinus.frepocery.ui.activity.signin.SignInActivity

class SuccessChangePassword : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_success_change_password)

    }
    fun postFinish(view: View?) {
        val i = Intent(this@SuccessChangePassword, SignInActivity::class.java)
        startActivity(i)
    }
}