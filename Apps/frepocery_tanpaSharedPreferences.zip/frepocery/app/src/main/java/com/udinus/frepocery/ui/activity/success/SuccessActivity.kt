package com.udinus.frepocery.ui.activity.success

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import com.udinus.frepocery.R
import com.udinus.frepocery.ui.activity.MainActivity


class SuccessActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_success)

//        intent
        Handler().postDelayed({
            val i = Intent(this@SuccessActivity, MainActivity::class.java)
            startActivity(i)
            finish()
        }, 1000)
    }
}