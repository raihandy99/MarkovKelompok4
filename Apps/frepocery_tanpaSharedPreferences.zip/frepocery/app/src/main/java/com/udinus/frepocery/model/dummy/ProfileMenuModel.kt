package com.udinus.frepocery.model.dummy

class ProfileMenuModel (title:String) {

    var title = ""

    init {
        this.title = title
    }

}