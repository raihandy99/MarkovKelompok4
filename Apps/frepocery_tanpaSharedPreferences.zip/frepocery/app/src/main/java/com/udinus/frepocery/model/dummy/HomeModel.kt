package com.udinus.frepocery.model.dummy

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class HomeModel (
    val title:String,
    val price:String,
    val src:Int,
    val rating:Float,
    val desc:String
) : Parcelable
